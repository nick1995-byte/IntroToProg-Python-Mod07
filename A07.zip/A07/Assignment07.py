# ------------------------------------------------------------------------------------------ #
# Title: Assignment07
# Desc: This assignment demonstrates using data classes with structured error handling
# Change Log: (Nick Tehrani, 8/10/2024, Created Script)
# ------------------------------------------------------------------------------------------ #
import json

# Define the Data Constants
MENU: str = '''
---- Course Registration Program ----
  Select from the following menu:  
    1. Register a Student for a Course.
    2. Show current data.  
    3. Save data to a file.
    4. Exit the program.
----------------------------------------- 
'''
FILE_NAME: str = "Enrollments.json"
FILE_NAME_CSV: str = "Enrollments.csv"

# Define the Data Variables
students: list = []  # Holds a table of student data
student_data_row: dict = {}  # Holds one row of student data
menu_choice: str  # Holds the choice made by the user.
csv_data: str = ''  # Holds combined string data separated by a comma.
file = None  # Holds a reference to an opened file.


# Processing --------------------------------------- #
class FileProcessor:
    """
    A collection of processing layer functions that work with Json files

    ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)
    """

    @staticmethod
    def read_data_from_file(file_name: str, student_data: list):
        """ This function reads data from a json file and loads it into a list of dictionary rows

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :param file_name: string data with name of file to read from
        :param student_data: list of dictionary rows to be filled with file data

        :return: list
        """

        try:
            file = open(file_name, "r")
            student_data = json.load(file)
            file.close()
        except Exception as e:
            IO.output_error_messages(message="Error: There was a problem with reading the file.", error=e)

        finally:
            if file.closed == False:
                file.close()
        return student_data

    @staticmethod
    def write_data_to_file(file_name: str, student_data: list):
        """ This function writes data to files with data from a list of dictionary rows

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :param file_name: string data with name of file to write to
        :param student_data: list of dictionary rows to be writen to the file

        :return: None
        """

        if ".json" in file_name:
            try:
                file = open(file_name, "w")
                json.dump(student_data, file)
                file.close()
                print("\nThe following data was written to a json file:")
                IO.output_student_courses(student_data=student_data)
            except Exception as e:
                message = "Error: There was a problem with writing to the file.\n"
                message += "Please check that the file is not open by another program."
                IO.output_error_messages(message=message, error=e)
            finally:
                if file.closed == False:
                    file.close()

        else:
            try:
                file = open(file_name, "w")
                for student in student_data:
                    csv_data = (f'{student["FirstName"]},{student["LastName"]},'
                                f'{student["CourseName"]}\n')
                    file.write(csv_data)
                file.close()
            except Exception as e:
                message = "Error: There was a problem with writing to the file.\n"
                message += "Please check that the file is not open by another program."
                IO.output_error_messages(message=message, error=e)
            finally:
                if file.closed == False:
                    file.close()


# Presentation --------------------------------------- #
class IO:
    """
    A collection of presentation layer functions that manage user input and output

    ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)
    """

    @staticmethod
    def input_menu_choice():
        """ This function gets a menu choice from the user and calls on other
        Functions based on each choice.

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :return: string with the users choice
        """

        global menu_choice
        global students

        while True:
            IO.output_menu(menu=MENU)
            menu_choice = input("What would you like to do: ")
            # Input user data
            if menu_choice == "1":
                students = IO.input_student_data(student_data=students)
                continue

            # Present the current data
            elif menu_choice == "2":
                IO.output_student_courses(student_data=students)
                continue

            # Save the data to a file
            elif menu_choice == "3":
                FileProcessor.write_data_to_file(FILE_NAME, student_data=students)
                FileProcessor.write_data_to_file(FILE_NAME_CSV, student_data=students)
                continue

            elif menu_choice not in ("1", "2", "3", "4"):
                print("Please only choose option 1, 2, 3, or 4")
                continue

            elif menu_choice == "4":
                break
        print("Program Ended")
        quit()

    @staticmethod
    def input_student_data(student_data: list):
        """ This function gets the student's first name and last name, with a course name from the user

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :param student_data: list of dictionary rows to be filled with input data

        :return: list
        """

        global student_data_row
        student = Student()
        student.first_name = input("\nEnter the student's first name: ")
        student.last_name = input("Enter the student's last name: ")
        student.course_name = input("Please enter the name of the course: ")
        student_data_row = {"FirstName": student.first_name, "LastName": student.last_name,
                            "CourseName": student.course_name}
        student_data.append(student_data_row)
        print()
        print(f"You have registered {student.first_name} {student.last_name} for {student.course_name}.")
        return student_data

    @staticmethod
    def output_menu(menu: str):
        """ This function displays the menu of choices to the user

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :return: None
        """

        print()  # Adding extra space to make it look nicer.
        print(menu)
        print()  # Adding extra space to make it look nicer.

    @staticmethod
    def output_student_courses(student_data: list):
        """ This function displays the student and course names to the user

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :param student_data: list of dictionary rows to be displayed

        :return: None
        """

        print("\n", "-" * 50)
        for student in student_data:
            print(f'Student {student["FirstName"]} '
                  f'{student["LastName"]} is enrolled in {student["CourseName"]}')
        print("-" * 50)

    @staticmethod
    def output_error_messages(message: str, error: Exception = None):
        """ This function displays a custom error messages to the user

        ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)

        :param message: string with message data to display
        :param error: Exception object with technical message to display

        :return: None
        """

        print(message, end="\n\n")
        if error is not None:
            print("-- Technical Error Message -- ")
            print(error, error.__doc__, type(error), sep='\n')


class Person:
    """
    This Class is used to create person objects which contain first and last name properties.
    The Class __str__ has been modified to return the actual first and last name values.
    ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)
    """

    def __init__(self, first_name: str = '', last_name: str = ''):
        """
        Adds first_name and last_name properties to the constructor
        :param first_name: first name value entered by the user
        :param last_name: last name value entered by the user
        """
        self.first_name = first_name  # Holds the first name entered by the user.
        self.last_name = last_name  # Holds the last name entered by the user.

    def __str__(self):
        """
        Method to extract comma separated data from class
        :return: comma separated data first and last name
        """
        return f"{self.first_name},{self.last_name}"

    @property
    def first_name(self):
        """
        Getter for first_name property
        :return: first_name
        """
        return self.__first_name

    @first_name.setter
    def first_name(self, value: str):
        """
        Setter for first_name property
        :param value: value being set in first_name
        :return: none
        """
        try:
            if value.isalpha() or value == "":  # allow characters or the default empty string
                self.__first_name = value
            else:
                raise ValueError("The first name should not contain numbers.")
        except ValueError as e:
            IO.output_error_messages(message=e.__str__(), error=e)
            IO.input_menu_choice()

    @property
    def last_name(self):
        """
        Getter for last_name property
        :return: last_name
        """
        return self.__last_name

    @last_name.setter
    def last_name(self, value: str):
        """
        Setter for last_name property
        :param value: value being set in last_name
        :return: none
        """
        try:
            if value.isalpha() or value == "":  # allow characters or the default empty string
                self.__last_name = value
            else:
                raise ValueError("The last name should not contain numbers.")
        except ValueError as e:
            IO.output_error_messages(message=e.__str__(), error=e)
            IO.input_menu_choice()


class Student(Person):
    """
    This Class inherits the first and last name properties from the Person Class and 
    combines them with the course_name value to create student objects. 
    The Class __str__ has been modified to return the first name, last name, and course name values.
    ChangeLog: (Nick Tehrani, 8/10/2024, Created Class)
    """

    def __init__(self, first_name: str = '', last_name: str = '', course_name: str = ''):
        """
        Call to the Person constructor and pass it the first_name and last_name data
        :param first_name: student first name entered by user
        :param last_name: student last name entered by user
        :param course_name: course name entered by user
        """
        super().__init__(first_name=first_name, last_name=last_name)
        self.__course_name = course_name

    def __str__(self):
        """
        Method to extract comma separated data from class
        :return: comma separated data for first, last, and course name
        """
        return f"{self.first_name},{self.last_name},{self.course_name}"

    @property
    def course_name(self):
        """
        Getter for course_name property
        :return: course name
        """
        return self.__course_name

    @course_name.setter
    def course_name(self, value: str):
        """
        Setter for course_name property
        :param value: value being set in course_name
        :return: none
        """
        # No validations for course input from user
        self.__course_name = value


# Start of main body

# When the program starts, read the file data into a list of lists (table)
# Extract the data from the file
students = FileProcessor.read_data_from_file(file_name=FILE_NAME, student_data=students)
# Show Menu and collect user input. Starts and manages program.
IO.input_menu_choice()
